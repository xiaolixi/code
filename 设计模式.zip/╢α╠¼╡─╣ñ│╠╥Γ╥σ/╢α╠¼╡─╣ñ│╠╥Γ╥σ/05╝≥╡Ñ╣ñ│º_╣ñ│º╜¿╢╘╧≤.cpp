#if 0

#include <iostream>
using namespace std;
class Fruit
{
public:
	virtual void getFruit() = 0;
};

class Banana: public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " Banana" << endl;
	}
};

class Apple : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " Apple" << endl;
	}
};

class Factory
{
public:
	Fruit* create(char* p)
	{
		if (strcmp(p, "banana") == 0)
		{
			cout << "create banana" << endl;
			return new Banana;
		}
		else if (strcmp(p, "apple") == 0)
		{
			cout << "create apple" << endl;
			return new Apple;
		}
		else
		{
			cout << " no create" << endl;
			return nullptr;
		}
	}
};
int main05()
{
	Factory* pFac = new Factory;

	Fruit* pApp = pFac->create("apple");
	pApp->getFruit();
	delete pApp;

	Fruit* pBan = pFac->create("banana");
	pBan->getFruit();
	delete pBan;

	delete pFac;
	getchar();
	return 0;
}
#endif