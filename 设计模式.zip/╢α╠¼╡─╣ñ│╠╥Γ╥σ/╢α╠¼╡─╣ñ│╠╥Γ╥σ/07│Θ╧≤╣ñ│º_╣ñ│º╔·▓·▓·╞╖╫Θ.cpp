#if 0

#include <iostream>
using namespace std;
class Fruit
{
public:
	virtual void getFruit() = 0;
};

class SouthApple : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " SouthApple" << endl;
	}
};
class SouthBanana : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " SouthBanana" << endl;
	}
};

class NorthApple : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " NorthApple" << endl;
	}
};
class NorthBanana : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " NorthBanana" << endl;
	}
};


class FruitFactory
{
public:
	virtual Fruit* createApple() = 0;
	virtual Fruit* createBanana() = 0;
};
class SouthFactory : public FruitFactory
{
public:
	virtual Fruit* createApple()
	{
		return new SouthApple;
	}
	virtual Fruit* createBanana()
	{
		return new SouthBanana;
	}
};
class NorthFactory : public FruitFactory
{
public:
	virtual Fruit* createApple()
	{
		return new NorthApple;
	}
	virtual Fruit* createBanana()
	{
		return new NorthBanana;
	}
};
int main07()
{
	FruitFactory* pFac = nullptr;
	Fruit* pFru = nullptr;

	pFac = new SouthFactory;
	pFru = pFac->createApple();
	pFru->getFruit();
	delete pFru;
	pFru = pFac->createBanana();
	pFru->getFruit();
	delete pFru;
	delete pFac;

	pFac = new NorthFactory;
	pFru = pFac->createApple();
	pFru->getFruit();
	delete pFru;
	pFru = pFac->createBanana();
	pFru->getFruit();
	delete pFru;
	delete pFac;

	getchar();
	return 0;
}

#endif
