#if 0

#include <iostream>
using namespace std;
class HardDisk
{
public:
	virtual void work() = 0;
};
class Memory
{
public:
	virtual void work() = 0;
};
class Cpu
{
public:
	virtual void work() = 0;
};
class XSHardDisk:public HardDisk
{
public:
	virtual void work()
	{
		cout << "XSHarDisk work well" << endl;
	}
};
class IntelCpu :public Cpu
{
public:
	virtual void work()
	{
		cout << "IntelCpu work well" << endl;
	}
};
class LiMemory :public Memory
{
public:
	virtual void work()
	{
		cout << "LiMemory work well" << endl;
	}
};

class Computer
{
public:
	Computer(HardDisk* disk, Cpu* cpu, Memory* memory)
		:m_disk(disk), m_cpu(cpu), m_memory(memory){};
	void work()
	{
		m_disk->work();
		m_cpu->work();
		m_memory->work();
	}
private:
	HardDisk* m_disk;
	Cpu* m_cpu;
	Memory* m_memory;
};
int main02()
{
	HardDisk* disk = new XSHardDisk;
	Cpu* cpu = new IntelCpu;
	Memory* memory = new LiMemory;

	Computer* computer = new Computer(disk, cpu, memory);
	computer->work();

	
	delete computer;
	delete memory;
	delete cpu;
	delete disk;

	getchar();
	return 0;
}

#endif