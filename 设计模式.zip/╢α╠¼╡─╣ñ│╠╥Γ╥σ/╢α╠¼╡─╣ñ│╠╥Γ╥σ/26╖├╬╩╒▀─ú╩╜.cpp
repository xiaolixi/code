#if 0

#include <iostream>
#include <list>

using namespace std;

class ParkElement;

class Visitor
{
public:
	virtual void visit(ParkElement* pe) = 0;
};

class ParkElement
{
public:
	virtual void accept(Visitor* v) = 0;
};

class ParkA : public ParkElement
{
public:
	void accept(Visitor* v)
	{
		v->visit(this);
	}
};

class ParkB : public ParkElement
{
public:
	void accept(Visitor* v)
	{
		v->visit(this);
	}
};

class VisitorA :public Visitor
{
public:
	void visit(ParkElement* pe)
	{
		cout << "Ա��A��ɨ�˹�԰A����" << endl;
	}
};

class VisitorB :public Visitor
{
public:
	void visit(ParkElement* pe)
	{
		cout << "Ա��B��ɨ�˹�԰B����" << endl;
	}
};
class Park :public ParkElement
{
public:
	void accept(Visitor* v)
	{
		for (list<ParkElement*>::iterator it = m_list.begin();
			it != m_list.end(); ++it)
		{
			(*it)->accept(v);
		}
	}
	void setParkElement(ParkElement* pe)
	{
		m_list.push_back(pe);
	}
private:
	list<ParkElement*> m_list;
};
class ManagerVisit :public Visitor
{
public:
	void visit(ParkElement* pe)
	{
		cout << "����Ա���������԰������ɨ���" << endl;
	}
};

int main26()
{
	/*ParkA* pA = nullptr;
	ParkB* pB = nullptr;
	VisitorA* pVA = nullptr;
	VisitorB* pVB = nullptr;

	pA = new ParkA;
	pB = new ParkB;
	pVA = new VisitorA;
	pVB = new VisitorB;

	pA->accept(pVA);
	pB->accept(pVB);
	delete pA;
	delete pB;
	delete pVA;
	delete pVB;*/

	Visitor* vM = nullptr;
	Park* pP = nullptr;
	ParkB* pB = nullptr;
	ParkA* pA = nullptr;
	pP = new Park;
	pB = new ParkB;
	pA = new ParkA;
	vM = new ManagerVisit;

	pP->setParkElement(pA);
	pP->setParkElement(pB);
	pP->accept(vM);
	
	delete pA;
	delete pB;
	delete pP;
	delete vM;

	return 0;
}

#endif