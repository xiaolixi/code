#if 0
#include <iostream>
using namespace std;
class abBank
{
public:
	virtual void doThing() = 0;
};
class saveBank:public abBank
{
public:
	virtual void doThing()
	{
		cout << "����" << endl;
	}
};

class moveBank:public abBank
{
public:
	virtual void doThing()
	{
		cout << "ת��" << endl;
	}
};

class advMoveBank:public abBank
{
public:
	virtual void doThing()
	{
		cout << "��������" << endl;
	}
};

 void doThing(abBank* p)
{
	p->doThing();
}
int main()
{
	abBank* pab = new saveBank;
	doThing(pab);
	delete pab;

	pab = new moveBank;
	doThing(pab);
	delete pab;

	pab = new advMoveBank;
	doThing(pab);
	delete pab;

	pab = new saveBank;
	doThing(pab);
	delete pab;

	return 0;
}

#endif