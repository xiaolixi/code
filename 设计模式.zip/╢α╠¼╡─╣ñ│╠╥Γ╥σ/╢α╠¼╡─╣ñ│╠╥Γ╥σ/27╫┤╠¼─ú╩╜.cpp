#if 0

#include <iostream>
using namespace std;
class Worker;

class State
{
public:
	virtual void doSomething(Worker* w) = 0;
};

class Worker
{
public:
	Worker();
	~Worker()
	{
		delete m_current;
	}
	int getHour()
	{
		return m_hour;
	}
	void setHour(int hour)
	{
		m_hour = hour;
	}
	void setCurrentState(State* state)
	{
		m_current = state;
	}
	State* getCurrentState()
	{
		return m_current;
	}
	void doSomethig()
	{
		m_current->doSomething(this);
	}
private:
	int m_hour;
	State* m_current;
};

class State1 :public State
{
public:
	void doSomething(Worker* w);
	
};
class State2 :public State
{
public:
	void doSomething(Worker* w);
};

void State1::doSomething(Worker* w)
{
	
	if (w->getHour() == 7 || w->getHour() == 8)
	{
		cout << "�����" << endl;
	}
	else
	{
		delete w->getCurrentState();
		w->setCurrentState(new State2);
		w->getCurrentState()->doSomething(w);
	}
}

void State2::doSomething(Worker* w)
{
	if (w->getHour() == 9 || w->getHour() == 10)
	{
		cout << "����" << endl;
	}
	else
	{
		delete w->getCurrentState(); //״̬2 ������Ҫת��״̬3 ���߻ָ�����ʼ��״̬
		w->setCurrentState(new State1); //�ָ�������״̬
		cout << "��ǰʱ��㣺" << w->getHour() << "δ֪״̬" << endl;
	}
}
Worker::Worker()
{
	m_current = new State1;
}
int main27()
{
	Worker* pWork = nullptr;
	pWork = new Worker;
	pWork->setHour(7);
	pWork->doSomethig();

	pWork->setHour(10);
	pWork->doSomethig();

	pWork->setHour(11);
	pWork->doSomethig();

	delete pWork;
	return 0;
}

#endif