#if 0
#include <iostream>
using namespace std;

typedef int Object;
#define SIZE 5

class Iterator
{
public:
	virtual void first() = 0;
	virtual void next() = 0;
	virtual bool isDone() = 0;
	virtual Object getCurrentItem() = 0;
};
class Aggreate
{
public:
	virtual int getSize() = 0;
	virtual Iterator* createIterator() = 0;
	virtual Object getItem(int index) = 0;
};

class MyIterator : public Iterator
{
public:
	MyIterator(Aggreate* agg)
	{
		m_Agg = agg;
		m_curIndex = 0;
	}
	virtual void first()
	{
		m_curIndex = 0;
	}
	virtual void next()
	{
		if (m_curIndex < m_Agg->getSize())
		{
			++m_curIndex;
		}
	}
	virtual bool isDone()
	{
		return m_curIndex == m_Agg->getSize();
	}
	virtual Object getCurrentItem()
	{
		return m_Agg->getItem(m_curIndex);
	}
private:
	int m_curIndex;
	Aggreate* m_Agg;
};

class MyAggreate : public Aggreate
{
public:
	MyAggreate()
	{
		for (int i = 0; i < SIZE; ++i)
		{
			m_a[i] = i + 20;
		}
	}
	virtual int getSize()
	{
		return SIZE;
	}
	virtual Iterator* createIterator()
	{
		return new MyIterator(this);
	}
	virtual Object getItem(int index)
	{
		return m_a[index];
	}
private:
	Object m_a[SIZE];
};

int main29()
{
	MyAggreate* pAgg = new MyAggreate;
	Iterator* pIter = pAgg->createIterator();
	for (; !(pIter->isDone()); pIter->next())
	{
		cout << pIter->getCurrentItem() << " " ;
	}

	delete pAgg;
	delete pIter;

	return 0;
}

#endif