#if 0

#include <iostream>
#include <string>
#include <map>

using namespace std;

//�Թ����ķ�ʽ��֧�ִ�����ϸ���ȵĶ���
class Person
{
public:
	Person(string name,int age)
	{
		m_age = age;
		m_name = name;
	}
	virtual ~Person()//����������������� �� ����ֻ��ִ�и������������
	{
		cout << "deconstructer Person" << endl;
	}
	virtual void print() = 0;
protected:
	string m_name;
	int m_age;
};

class Teacher : public Person
{
public:
	Teacher(string name, int age, string id)
		:Person(name, age), m_id(id){}
	~Teacher()
	{
		cout << "deconstructer Teacher" << endl;
	}
	void print()
	{
		cout << m_name << " " << m_age << " " << m_id << endl;
	}
protected:
	string m_id;
};

class FlyWeightTeacherFactory
{
public:
	FlyWeightTeacherFactory()
	{
		m_map.clear();
	}
	~FlyWeightTeacherFactory()
	{
		while (!m_map.empty())
		{
			map<string, Person*>::iterator it;
			it = m_map.begin();
			delete it->second;
			m_map.erase(it);
		}
	}
	Person* getTeacher(string id)
	{
		map<string, Person*>::iterator it;
		it = m_map.find(id);
		if (it == m_map.end())
		{
			Person* pTeacher = nullptr;
			string name;
			int age;
			cout << " input teacher's name: ";
			cin >> name;
			cout << " intput teacher's age: ";
			cin >> age;
			pTeacher = new Teacher(name, age, id);
			m_map.insert(pair<string, Person*>(id, pTeacher));
			return pTeacher;
		}
		else
		{
			return it->second;
		}
	}
private:
	map<string, Person*> m_map;
};

int main17()
{
	Person* pTeacher = nullptr;
	FlyWeightTeacherFactory* pFly = nullptr;

	pFly = new FlyWeightTeacherFactory();
	pTeacher = pFly->getTeacher("001");
	pTeacher->print();

	pTeacher = pFly->getTeacher("001");
	pTeacher->print();
	delete pFly;

	return 0;
}

#endif