#if 0

#include <iostream>
#include <list>
#include <string>
#include <algorithm>
using namespace std;
class Stock
{
public:
	void doThing()
	{
		cout << " do stock" << endl;
	}
};
class Bond//ծȯ
{
public:
	void doThing()
	{
		cout << " do bond" << endl;
	}
};
class Furture//�ڻ�
{
public:
	void doThing()
	{
		cout << " do furture" << endl;
	}
};
class Facade
{
public:
	Facade()
	{
		m_bond = new Bond;
		m_furture = new Furture;
		m_stcok = new Stock;
	}
	~Facade()
	{
		delete m_bond;
		delete m_furture;
		delete m_stcok;
	}
	void doAggressive()
	{
		m_bond->doThing();
		m_stcok->doThing();
	}
	void doStable()
	{
		m_furture->doThing();
	}
private:
	Stock* m_stcok;
	Furture* m_furture;
	Bond* m_bond;
};
int main16()
{
	Facade* pFac = new Facade;
	pFac->doAggressive();
	delete pFac;

	return 0;
}

#endif 