#if 0

#include <iostream>
#include <string>
using namespace std;

class House
{
public:
	void setDoor(string door)
	{
		this->m_door = door;
	}
	void setWindow(string window)
	{
		this->m_window = window;
	}
	void setWall(string wall)
	{
		this->m_wall = wall;
	}

	string getDoor()
	{
		cout << m_door << endl;
		return m_door;
	}
	string getWall()
	{
		cout << m_wall << endl;
		return m_wall;
	}
	string getWindow()
	{
		cout << m_window << endl;
		return m_window;
	}
private:
	string m_door;
	string m_wall;
	string m_window;
};
class Builder
{
public:
	virtual void buildWall() = 0;
	virtual void buildDoor() = 0;
	virtual void buildWindow() = 0;
	virtual House* getHouse() = 0;
};
class FaltBuilder:public Builder
{
public:
	FaltBuilder()
	{
		m_house = new House;
	}
	virtual void buildWall()
	{
		m_house->setWall("falt wall");
	}
	virtual void buildDoor()
	{
		m_house->setDoor("falt door");
	}
	virtual void buildWindow()
	{
		m_house->setWindow("falt window");
	}
	virtual House* getHouse()
	{
		return m_house;
	}
private:
	House* m_house;
};
//����
class VillaBuilder :public Builder
{
public:
	VillaBuilder()
	{
		m_house = new House;
	}
	virtual void buildWall()
	{
		m_house->setWall("Villa wall");
	}
	virtual void buildDoor()
	{
		m_house->setDoor("Villa door");
	}
	virtual void buildWindow()
	{
		m_house->setWindow("Villa window");
	}
	virtual House* getHouse()
	{
		return m_house;
	}
private:
	House* m_house;
};
class Director
{
public:
	Director(Builder* build)
	{
		m_bulid = build;
	}
	void Construct()
	{
		m_bulid->buildWall();
		m_bulid->buildDoor();
		m_bulid->buildWindow();
	}
private:
	Builder* m_bulid;
};
int main09()
{
	Builder* builder = nullptr;
	Director* director = nullptr;
	House* house = nullptr;

	builder = new VillaBuilder;	
	director = new Director(builder);
	director->Construct();
	house = builder->getHouse();
	house->getDoor();
	house->getWall();
	delete house;
	delete builder;


	builder = new FaltBuilder;
	director = new Director(builder);
	director->Construct();
	house = builder->getHouse();
	house->getDoor();
	house->getWall();
	delete house;
	delete builder;

	delete director;
	return 0;
}
#endif