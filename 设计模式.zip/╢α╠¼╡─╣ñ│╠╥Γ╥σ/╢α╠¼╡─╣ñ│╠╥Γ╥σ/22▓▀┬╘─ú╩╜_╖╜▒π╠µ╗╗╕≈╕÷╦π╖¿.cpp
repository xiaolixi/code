#if 0

//׼��һ���㷨����ÿһ���㷨��װ��һ���࣬ʹ�ÿ����滻
#include <iostream>
#include <list>
#include <string>
using namespace std;


class Strategy
{
public:
	virtual void crypt() = 0;
};
//�ԳƼ���
//�ǶԳƼ��� ����ǿ�ȸ� ��ȫ ��Կ˽Կ
class DES : public Strategy
{
public:
	virtual void crypt()
	{
		cout << "DES crypt" << endl;
	}
};

class AES : public Strategy
{
public:
	virtual void crypt()
	{
		cout << "AES crypt" << endl;
	}
};

class Conenxt
{
public:
	void setCrypt(Strategy* stratey)
	{
		m_strategy = stratey;
	}
	void operation()
	{
		m_strategy->crypt();
	}
private:
	Strategy* m_strategy;
};

int main22()
{
	//1
	/*DES* des = new DES;
	des->crypt();
	delete des;*/

	Conenxt* pCon = nullptr;
	Strategy* pDes = nullptr;
	pDes = new DES;
	pCon = new Conenxt;
	pCon->setCrypt(pDes);
	pCon->operation();

	delete pDes;
	delete pCon;
	return 0;
}




#endif