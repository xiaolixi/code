#if 0

#include <iostream>
using namespace std;
class Fruit
{
public:
	virtual void getFruit() = 0;
};

class Banana : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " Banana" << endl;
	}
};

class Apple : public Fruit
{
public:
	virtual void getFruit()
	{
		cout << " Apple" << endl;
	}
};

class FruitFactory
{
public:
	virtual Fruit* createFruit() = 0;
	
};
class AppleFactory : public FruitFactory
{
public:
	virtual Fruit* createFruit()
	{
		return new Apple;
	}
};
class BananaFactory : public FruitFactory
{
public:
	virtual Fruit* createFruit() 
	{
		return new Banana;
	}
};
int main06()
{
	FruitFactory* pFac = nullptr;
	Fruit* pFru = nullptr;

	pFac = new AppleFactory;
	pFru = pFac->createFruit();
	pFru->getFruit();
	delete pFru;
	delete pFac;

	pFac = new BananaFactory;
	pFru = pFac->createFruit();
	pFru->getFruit();
	delete pFru;
	delete pFac;
	
	getchar();
	return 0;
}

#endif