#if 0

//����Ľӿ�ת�����ʺϵ��õĽӿ�
#include <iostream>
using namespace std;

class Current18v
{
	virtual void useCurrent18v() = 0;
};

class Current220v
{
public:
	void useCurrent220v()
	{
		cout << " 220V " << endl;
	}
};

class Adapter : public Current18v
{
public:
	Adapter(Current220v* current)
	{
		m_current = current;
	}
	void useCurrent18v()
	{
		cout << " adapter use 220V " << endl;
		m_current->useCurrent220v();
	}
private:
	Current220v* m_current;
};

int main13()
{
	Adapter* pAde = nullptr;
	Current220v* pC220 = nullptr;

	pC220 = new Current220v;
	pAde = new Adapter(pC220);
	pAde->useCurrent18v();

	delete pC220;
	delete pAde;

	return 0;
}

#endif