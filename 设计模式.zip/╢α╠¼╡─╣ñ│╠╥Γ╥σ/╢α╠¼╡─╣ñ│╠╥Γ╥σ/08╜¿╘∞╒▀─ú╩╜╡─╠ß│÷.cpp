#if 0

#include <iostream>
#include <string>
using namespace std;

class House
{
public:
	void setDoor(string door)
	{
		this->m_door = door;
	}
	void setWindow(string window)
	{
		this->m_window = window;
	}
	void setWall(string wall)
	{
		this->m_wall = wall;
	}

	string getDoor()
	{
		cout << m_door << endl;
		return m_door;
	}
	string getWall()
	{
		cout << m_wall << endl;
		return m_wall;
	}
	string getWindow()
	{
		cout << m_window << endl;
		return m_window;
	}
private:
	string m_door;
	string m_wall;
	string m_window;
};

class Builder
{
public:
	Builder()
	{
		m_house = new House;
	}
	void DuildHouse()
	{
		buildDoor();
		buildWall();
		buildWindow();
	}
	void buildDoor()
	{
		m_house->setDoor("door");
	}
	void buildWall()
	{
		m_house->setWall("wall");
	}
	void buildWindow()
	{
		m_house->setWindow("window");
	}
	House* getHouse()
	{
		return m_house;
	}
private:
	House* m_house;
};
int main08()
{
	/*
	House house;
	house.setDoor("door");
	house.setWall("wall");
	house.setWindow("window");
	*/

	Builder* build = new Builder;
	build->DuildHouse();
	House* house = build->getHouse();
	house->getDoor();
	house->getWall();
	house->getWindow();

	delete house;
	delete build;

	getchar();
	return 0;
}

#endif