#if 0

#include <iostream>
#include <string>
#include <deque>

using namespace std;
class MememTo
{
public:
	MememTo(string name, int age) :m_name(name), m_age(age){}
	void setName(string name)
	{
		m_name = name;
	}
	string getName()
	{
		return m_name;
	}

	void setAge(int age)
	{
		m_age = age;
	}
	int getAge()
	{
		return m_age;
	}
private:
	string m_name;
	int m_age;
};

class Person
{
public:
	Person(string name, int age) :m_name(name), m_age(age)
	{
		//m_pMem = nullptr;
	}
	void print()
	{
		cout << m_name << " " << m_age << endl;
	}
	void setName(string name)
	{
		m_name = name;
	}
	string getName()
	{
		return m_name;
	}

	void setAge(int age)
	{
		m_age = age;
	}
	int getAge()
	{
		return m_age;
	}
	MememTo* createMememTo()
	{
		return new MememTo(m_name, m_age);
	}
	void getMememTo(MememTo* m)
	{
		if(m != nullptr)
		{
			m_name = m->getName();
			m_age = m->getAge();
			delete m;
		}
	}
private:
	string m_name;
	int m_age;
};

class Caretaker
{
public:
	Caretaker()
	{
		m_deque.clear();
	}
	~Caretaker()
	{
		for (deque<MememTo*>::iterator it = m_deque.begin();
			it != m_deque.end(); ++it)
		{
			delete (*it);
		}
		m_deque.clear();
	}
	void setMememTo(MememTo* m)
	{
		if (m_deque.size() != 10)
		{
			m_deque.push_back(m);
		}
		else
		{
			delete m_deque[0];
			m_deque.pop_front();
			m_deque.push_back(m);
		}
	}
	MememTo* getMememTo()
	{
		if (!m_deque.empty())
		{
			MememTo* temp = *(m_deque.rbegin());
			m_deque.pop_back();
			return temp;
		}
		else
		{
			return nullptr;
		}
	}
private:
	deque<MememTo*> m_deque;
};
int main()
{
	Person* pPerson = nullptr;
	Caretaker* pC = nullptr;

	pPerson = new Person("zhang", 33);
	pPerson->print();

	pC = new Caretaker;
	pC->setMememTo(pPerson->createMememTo());

	pPerson->setName("lixi");
	pPerson->setAge(32);
	pC->setMememTo(pPerson->createMememTo());

	pPerson->getMememTo(pC->getMememTo());
	pPerson->print();

	pPerson->getMememTo(pC->getMememTo());
	pPerson->print();

	//�Ѿ�û��״̬��,��������ԭ�ȵ�״̬
	pPerson->getMememTo(pC->getMememTo());
	pPerson->print();
	delete pC;
	delete pPerson;
	return 0;
}

#endif