//shift + u -> 
//shift + ctrl + u -> toUp

#include <iostream>
#include <list>
#include <string>
using namespace std;
//struct demo
//{
//	char mm;
//	int ii;
//	struct demo* pNext;
//};
class Car
{
public:
	virtual void makeCar() = 0;
	void setNextHandle(Car* handle)
	{
		m_next = handle;
	}
protected:
	Car* m_next;//��һ��������Ԫ
};

class HeadCarHandle : public Car
{
public:
	void makeCar()
	{
		cout << " construct car head" << endl;
		if (m_next != nullptr)//������һ��������Ԫ
		{
			m_next->makeCar();
		}
	}
};

class BodyCarHandle : public Car
{
public:
	void makeCar()
	{
		cout << " construct car body" << endl;
		if (m_next != nullptr)//������һ��������Ԫ
		{
			m_next->makeCar();			
		}
	}
};

class TailCarHandle : public Car
{
public:
	void makeCar()
	{
		cout << " construct car tail" << endl;
		if (m_next != nullptr)//������һ��������Ԫ
		{
			m_next->makeCar();
		}
	}
};
int main21()
{
	Car* headCar = new HeadCarHandle;
	Car* tailCar = new TailCarHandle;
	Car* bodyCar = new BodyCarHandle;

	//ҵ���߼�д�����˿ͻ���
	/*
	headCar->makeCar();
	tailCar->makeCar();
	bodyCar->makeCar();
	*/

	headCar->setNextHandle(tailCar);
	tailCar->setNextHandle(bodyCar);
	bodyCar->setNextHandle(nullptr);
	headCar->makeCar();

	delete headCar;
	delete tailCar;
	delete bodyCar;

	return 0;
}