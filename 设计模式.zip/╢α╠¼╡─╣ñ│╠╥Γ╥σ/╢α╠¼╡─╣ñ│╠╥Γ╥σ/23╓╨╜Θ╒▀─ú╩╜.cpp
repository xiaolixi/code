#if 0

#include <iostream>
#include <string>
using namespace std;

class Mediator;

class Person
{
public:
	Person(string name, int sex, int condition,Mediator* mediator)
	{
		m_name = name;
		m_sex = sex;
		m_condition = condition;
		m_mediator = mediator;
	}
	int getCondition()
	{
		return m_condition;
	}
	int getSex()
	{
		return m_sex;
	}
	string getName()
	{
		return m_name;
	}
	virtual void getParter(Person* parter) = 0;
protected:
	string m_name;
	int m_sex;
	int m_condition;
	Mediator* m_mediator;
};
class Mediator
{
public:
	void setMan(Person* man)
	{
		m_pMan = man;
	}
	void setWonman(Person* wonman)
	{
		m_pWonman = wonman;
	}
	void getParter()
	{
		if (m_pMan->getSex() == m_pWonman->getSex())
		{
			cout << "ͬ�Բ�������" << endl;
			return;
		}
		if (m_pMan->getCondition() == m_pWonman->getCondition())
		{
			cout << m_pMan->getName() << "��" << m_pWonman->getName() << "����" << endl;
		}
		else
		{
			cout << m_pMan->getName() << "��" << m_pWonman->getName() << "����" << endl;
		}
	}
private:
	Person* m_pMan;
	Person* m_pWonman;
};

class Wonman :public Person
{
public:
	Wonman(string name, int sex, int condition,Mediator* mediator)
		:Person(name, sex, condition,mediator){}
	void getParter(Person* parter)
	{
		m_mediator->setMan(parter);
		m_mediator->setWonman(this);
		m_mediator->getParter();
	}
};

class Man :public Person
{
public:
	Man(string name, int sex, int condition,Mediator* mediator)
		:Person(name,sex,condition,mediator){}
	void getParter(Person* parter)
	{
		m_mediator->setMan(this);
		m_mediator->setWonman(parter);
		m_mediator->getParter();
	}
};


int main()
{
	Mediator* mediator = new Mediator;

	Person* xiaofang = new Wonman("С��", 2, 5, mediator);
	Person* zhangsan = new Man("����", 1, 4, mediator);
	Person* lixi = new Man("��ϰ", 1, 5, mediator);

	xiaofang->getParter(zhangsan);
	xiaofang->getParter(lixi);

	delete xiaofang;
	delete zhangsan;
	delete lixi;
	delete mediator;

	return 0;
}

#endif


#if 0

#include <iostream>
#include <string>
#include <list>
using namespace std;
#define WONMAN 1
#define MAN 0
class DatingAgency;

class Person
{
public:
	Person(string name, int sex, int condition, DatingAgency* da)
		:m_name(name), m_sex(sex), m_condition(condition), m_DA(da){}
	int getSex()const { return m_sex; }
	int getCondition()const { return m_condition; }
	string getName()const { return m_name; }
	virtual void findParter() = 0;
protected:
	string m_name;	
	int m_sex;
	int m_condition;
	DatingAgency* m_DA;
};

class DatingAgency
{
public:
	DatingAgency()
	{
		m_WonList.clear();
		m_ManList.clear();
	}
	void setWonman(Person* wonman)
	{
		if (wonman->getSex() == WONMAN)
		{
			m_WonList.push_back(wonman);
		}
	}
	void setMan(Person* man)
	{
		if (man->getSex() == MAN)
		{
			m_ManList.push_back(man);
		}
	}
	void findParter(Person* guest)
	{
		bool found = false;
		list<Person*>::iterator it;
		if (guest->getSex() == WONMAN)
		{
			for (it = m_ManList.begin(); it != m_ManList.end(); ++it)
			{
				if (guest->getCondition() == (*it)->getCondition())
				{
					found = true;
					cout << guest->getName() << "��" << (*it)->getName()
						<< "�������ϣ�������Լ����*^_^*" << endl;
				}
			}
			if (found == false)
			{
				cout << "Ŀǰû���������ϣ�ʮ�ֱ�Ǹ-_-" << endl;
			}
		}
		else
		{
			for (it = m_WonList.begin(); it != m_WonList.end(); ++it)
			{
				if (guest->getCondition() == (*it)->getCondition())
				{
					found = true;
					cout << guest->getName() << "��" << (*it)->getName()
						<< "�������ϣ�������Լ����*^_^*" << endl;
				}
			}
			if (found == false)
			{
				cout << "Ŀǰû���������ϣ�ʮ�ֱ�Ǹ-_-" << endl;
			}
		}
	}
private:
	list<Person*> m_ManList;
	list<Person*> m_WonList;
};
class Wonman :public Person
{
public:
	Wonman(string name, int sex, int condition, DatingAgency* da)
		:Person(name,sex, condition,da){}
	virtual void findParter()
	{
		m_DA->findParter(this);
	}
};

class Man :public Person
{
public:
	Man(string name, int sex, int condition, DatingAgency* da)
		:Person(name, sex, condition, da){}
	virtual void findParter()
	{
		m_DA->findParter(this);
	}
};


int main()
{
	DatingAgency* pDating = new DatingAgency;

	Person* zhangsan = new Man("����", MAN, 4, pDating);
	Person* lixi = new Wonman("����", MAN, 5, pDating);
	Person* xiaofang = new Wonman("С��", WONMAN, 5, pDating);
	pDating->setMan(zhangsan);
	pDating->setMan(lixi);
	pDating->setWonman(xiaofang);

	xiaofang->findParter();
	zhangsan->findParter();

	delete xiaofang;
	delete lixi;
	delete zhangsan;
	delete pDating;

	return 0;
}

#endif