#if 0

#include <iostream>
using namespace std;

class Engine
{
public:
	virtual void installEngine() = 0;
};

class Engine4400cc :public Engine
{
public:
	virtual void installEngine()
	{
		cout << "4400cc" << endl;
	}
};

class Engine5400cc :public Engine
{
public:
	virtual void installEngine()
	{
		cout << "5400cc" << endl;
	}
};

class Car
{
public:
	virtual void installEngine() = 0;
	Car(Engine* engine)
	{
		m_engine = engine;
	}
protected:
	Engine* m_engine;
};

class WBM5:public Car
{
public:
	virtual void installEngine()
	{
		cout << "WBM5 install" << endl;
		m_engine->installEngine();
	}
	WBM5(Engine* engine) :Car(engine){}
};

int main14()
{
	Car* pCar = nullptr;
	Engine* pEng = nullptr;

	pEng = new Engine4400cc;
	pCar = new WBM5(pEng);
	pCar->installEngine();

	delete pCar;
	delete pEng;

	return 0;
}

#endif