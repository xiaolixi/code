#if 0

#include <iostream>
#include <string>

using namespace std;

class Context
{
public:
	Context(int num)
	{
		m_num = num;
	}
	void setNum(int num)
	{
		m_num = num;
	}
	void setRes(int res)
	{
		m_res = res;
	}
	int getNum()
	{
		return m_num;
	}
	int getRes()
	{
		return m_res;
	}
private:
	int m_num;
	int m_res;
};
class Expression
{
public:
	virtual void interpreter(Context* context) = 0;
};
class PlusExpression:public Expression
{
public:
	virtual void interpreter(Context* context)
	{
		int n = context->getNum();
		++n;
		context->setNum(n);
		context->setRes(n);
	}
};
class MinusExpression :public Expression
{
public:
	virtual void interpreter(Context* context)
	{
		int n = context->getNum();
		--n;
		context->setNum(n);
		context->setRes(n);
	}
};

int main()
{
	Context* pCon = new Context(10);
	Expression* pEp = new PlusExpression;
	pEp->interpreter(pCon);
	cout << pCon->getRes() << endl;

	Expression* pEm = new MinusExpression;
	pEm->interpreter(pCon);
	cout << pCon->getRes() << endl;

	delete pEm;
	delete pEp;
	delete pCon;

}

#endif