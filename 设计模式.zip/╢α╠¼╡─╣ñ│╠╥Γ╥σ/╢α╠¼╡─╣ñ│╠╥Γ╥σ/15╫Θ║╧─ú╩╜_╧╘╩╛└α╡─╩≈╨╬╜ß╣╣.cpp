#if 0

#include <iostream>
#include <list>
#include <string>
#include <algorithm>
using namespace std;

class IFile
{
public:
	virtual void display(int level) = 0;
	virtual int add(IFile* ifile) = 0;
	virtual int remove(IFile* ifile) = 0;
	virtual list< IFile* > * getChild() = 0;
};

class File:public IFile
{
public:
	File(string name)
	{
		m_name = name;
	}
	virtual void display(int level)
	{
		for (int i = 0; i < level; ++i)
		{
			cout << "--";
		}
		cout << m_name << endl;
	}
	virtual int add(IFile* ifile)
	{
		return -1;
	}
	virtual int remove(IFile* ifile)
	{
		return -1;
	}
	virtual list< IFile* >* getChild()
	{
		return nullptr;
	}
private:
	string m_name;
};

class Floder :public IFile
{
public:
	Floder(string name)
	{
		m_name = name;
		m_list = new list<IFile*>;
		m_list->clear();
	}
	virtual void display(int level)
	{
		for (int i = 0; i < level; ++i)
		{
			cout << "--";
		}
		cout << m_name << endl;

		//ShowTree()�������ã���ȥ���д���
		list<IFile*>::iterator it = m_list->begin();
		for (; it != m_list->end(); ++it)
		{
			(*it)->display(level+1);
		}
	}
	virtual int add(IFile* ifile)
	{
		m_list->push_back(ifile);
		return 0;
	}
	virtual int remove(IFile* ifile)
	{
		if (m_list->end() == find(m_list->begin(), m_list->end(), ifile))
		{
			return -1;
		}
		else
		{
			m_list->remove(ifile);
			return 0;
		}
		
	}
	virtual list<IFile*>* getChild()
	{
		return m_list;
	}
private:
	string m_name;
	list<IFile*>* m_list;
};

//void ShowTree(IFile* root,int level)
//{
//	if (root == nullptr)
//	{
//		return;
//	}
//	root->display(level);
//
//	list<IFile*>* p = root->getChild();
//	if (p != nullptr)
//	{
//		list<IFile*>::iterator it = p->begin();
//		for (; it != p->end(); ++it)
//		{
//			if ((*it)->getChild() == nullptr)
//			{				
//				(*it)->display(level);
//			}
//			else
//			{
//				ShowTree(*it,level+1);
//			}
//		}
//	}	
//}
int main15()
{
	Floder* pFlo = nullptr;
	pFlo = new Floder("C:");
	Floder* p111 = new Floder("111:");
	File* paaa = new File("aaa.txt");

	Floder* p222 = new Floder("222:");
	File* pbbb = new File("bbb.txt");
	p111->add(p222);
	p111->add(pbbb);

	pFlo->add(p111);
	pFlo->add(paaa);

	pFlo->display(0);
	p111->display(1);
	//���display()ֻ��ʾ�Լ������֣���������
	//ShowTree(pFlo,0);
	//ShowTree(p111, 1);
	delete p111;
	delete p222;
	delete paaa;
	delete pbbb;
	delete pFlo;
	return 0;
}

#endif