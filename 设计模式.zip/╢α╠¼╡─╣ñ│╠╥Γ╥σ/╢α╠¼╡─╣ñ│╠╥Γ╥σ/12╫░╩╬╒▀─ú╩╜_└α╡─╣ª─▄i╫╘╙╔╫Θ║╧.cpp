#if 0

#include <iostream>
using namespace std;

class Car
{
public:
	virtual void show() = 0;
};

class RunCar :public Car
{
public:
	virtual void show()
	{
		cout << "������" << endl;
	}
};

class SwimCarDirector :public Car
{
public:
	SwimCarDirector(Car* car)
	{
		m_car = car;
	}
	void swim()
	{
		cout << "������Ӿ" << endl;
	}
	void show()
	{
		m_car->show();
		swim();
	}
private:
	Car* m_car;
};

class FlyCarDirector :public Car
{
public:
	FlyCarDirector(Car* car)
	{
		m_car = car;
	}
	void fly()
	{
		cout << "���Է�" << endl;
	}
	void show()
	{
		m_car->show();
		fly();
	}
private:
	Car* m_car;
};

int main12()
{
	Car* run = new RunCar;
	run->show();
	cout << "\n";

	Car* swim = new SwimCarDirector(run);
	swim->show();
	cout << "\n";

	Car* fly = new FlyCarDirector(swim);
	fly->show();

	delete fly;
	delete swim;
	delete run;

	return 0;
}

#endif