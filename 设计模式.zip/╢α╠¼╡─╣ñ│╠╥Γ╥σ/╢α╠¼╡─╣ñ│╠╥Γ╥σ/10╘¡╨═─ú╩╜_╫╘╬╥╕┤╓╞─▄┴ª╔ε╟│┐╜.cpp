#if 0

#include <iostream>
#include <string>
using namespace std;
//ԭ��ģʽ��ʹһ�����ӵĶ���������Ҹ��ƹ���
//��Ҫ����ǳ�������������
//����ָ���������

class Person
{
public:
	virtual Person* clone() = 0;
	virtual void print() = 0;
};

class CplusplusProgrammer: public Person
{
public:
	CplusplusProgrammer(/*string name,int age*/)
	{
		m_name = "";// name;
		m_age = 0;// age;
		setResume("cplusplus");
	}
	CplusplusProgrammer(string name,int age)
	{
		m_name =  name;
		m_age = age;
		setResume("cplusplus");
	}
	void setResume(char* p)
	{
		if (m_resume != nullptr)
		{
			delete m_resume;
		}
		m_resume = new char[strlen(p) + 1];
		strcpy_s(m_resume, strlen(p) + 1, p);
	}
	CplusplusProgrammer& operator=(const CplusplusProgrammer& oh)
	{
		if (this != &oh)
		{
			this->m_age = oh.m_age;
			this->m_name = oh.m_name;
			this->m_resume = oh.m_resume;
		}
		return *this;
	}
	Person* clone()
	{
		CplusplusProgrammer* temp =  new CplusplusProgrammer;
		//temp->m_age = this->m_age;
		//temp->m_name = this->m_name;
		*temp = *this;//��Ϊc++�ĸ�ֵ���죬ǳ����
		temp->m_resume = new char[strlen(this->m_resume) + 1];
		strcpy_s(temp->m_resume, strlen(this->m_resume) + 1, this->m_resume);
		return temp;
	}
	void print()
	{
		cout << m_name << " " << m_age << endl;
		cout << m_resume << " pointer to " << m_resume[3] << " and at the " << &m_resume << endl;
	}
private:
	string m_name;
	int m_age;
	char* m_resume;

};
int main10()
{
	Person* pC = new CplusplusProgrammer("����", 20);
	pC->print();

	Person* pC2 = pC->clone();
	pC2->print();
	return 0;
}
#endif