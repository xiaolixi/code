#if 0

//��һ�������װΪһ������ʹ�ÿ����ò�ͬ�����󽫿ͻ��˽��в�����
//�������Ŷ� ������־ ��������
#include <iostream>
#include <list>
#include <string>
using namespace std;

class Doctor
{
public:
	Doctor(string name) :m_name(name){}
	void treatEye()
	{
		cout << m_name << " treat eyes" << endl;
	}
	void treatNose()
	{
		cout << m_name <<" treat nose" << endl;
	}
	void treatEar()
	{
		cout << m_name << " treat Ears" << endl;
	}
private:
	string m_name;
};

class Command
{
public:
	virtual void treat() = 0;
};

class CommandTreatEye : public Command
{
public:
	CommandTreatEye(Doctor* doctor)
	{
		m_doctor = doctor;
	}
	void treat()
	{
		m_doctor->treatEye();
	}
private:
	Doctor* m_doctor;
};



class CommandTreatEar : public Command
{
public:
	CommandTreatEar(Doctor* doctor)
	{
		m_doctor = doctor;
	}
	void treat()
	{
		m_doctor->treatEar();
	}
private:
	Doctor* m_doctor;
};

class CommandTreatNose : public Command
{
public:
	CommandTreatNose(Doctor* doctor)
	{
		m_doctor = doctor;
	}
	void treat()
	{
		m_doctor->treatNose();
	}
private:
	Doctor* m_doctor;
};

class BeautyNurse
{
public:
	BeautyNurse(Command* command)
	{
		m_command = command;
	}
	void submitCare()
	{
		m_command->treat();
	}
private:
	Command* m_command;
};

class AdvNurse
{
public:
	AdvNurse()
	{
		m_list.clear();
	}
	void setCommand(Command* command)
	{
		m_list.push_back(command);
	}
	void submitCare()
	{
		for (list<Command*>::iterator it = m_list.begin();
			it != m_list.end(); ++it)
		{
			(*it)->treat();
		}
	}
private:
	list<Command* > m_list;
};
int main()
{
	//1 ҽ��ֱ���β�
	/*
	Doctor* pDoc = nullptr;
	pDoc = new Doctor;
	pDoc->treatEar();
	pDoc->treatEye();
	pDoc->treatNose();
	delete pDoc;
	*/

	//2 ͨ�������
	/*
	Doctor* pDoc = nullptr;
	CommandTreatEye* pComEye = nullptr;
	CommandTreatEar* pComEar = nullptr;

	pDoc = new Doctor;
	pComEar = new CommandTreatEar(pDoc);
	pComEar->treat();
	pComEye = new CommandTreatEye(pDoc);
	pComEye->treat();

	delete pDoc;
	delete pComEar;
	delete pComEye;
	*/

	//3 ��ʿ�ύ����
	/*
	Doctor* pDoc = nullptr;	
	Command* pComEar = nullptr;
	BeautyNurse* pNur = nullptr;

	pDoc = new Doctor;
	pComEar = new CommandTreatEar(pDoc);	
	pNur = new BeautyNurse(pComEar);
	pNur->submitCare();
	
	delete pNur;
	delete pComEar;
	delete pDoc;
	*/

	Doctor* pDoc1 = nullptr;
	Doctor* pDoc2 = nullptr;
	Command* pComEar = nullptr;
	Command* pComEye = nullptr;
	AdvNurse* pAdvNur = nullptr;

	pDoc1 = new Doctor("Lixi");
	pDoc2 = new Doctor("FeiDeng");
	pComEar = new CommandTreatEar(pDoc1);
	pComEye = new CommandTreatEye(pDoc2);

	pAdvNur = new AdvNurse;
	pAdvNur->setCommand(pComEar);
	pAdvNur->setCommand(pComEye);
	pAdvNur->submitCare();

	delete pAdvNur;
	delete pComEar;
	delete pComEye;
	delete pDoc2;
	delete pDoc1;

	return 0;
}

#endif