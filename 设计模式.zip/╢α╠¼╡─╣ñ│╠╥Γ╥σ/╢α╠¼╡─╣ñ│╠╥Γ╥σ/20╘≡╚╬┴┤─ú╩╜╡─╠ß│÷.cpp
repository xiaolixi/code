

//shift + u -> 
//shift + ctrl + u -> toUp
#if 0
#include <iostream>
#include <list>
#include <string>
using namespace std;

class Car
{
public:
	virtual void makeCar() = 0;
};

class HeadCarHandle : public Car
{
public:
	void makeCar()
	{
		cout << " construct car head" << endl;
	}
};

class BodyCarHandle : public Car
{
public:
	void makeCar()
	{
		cout << " construct car body" << endl;
	}
};

class TailCarHandle : public Car
{
public:
	void makeCar()
	{
		cout << " construct car tail" << endl;
	}
};
int main20()
{
	Car* headCar = new HeadCarHandle;
	Car* tailCar = new TailCarHandle;
	Car* bodyCar = new BodyCarHandle;

	//ҵ���߼�д�����˿ͻ���
	headCar->makeCar();
	tailCar->makeCar();
	bodyCar->makeCar();

	delete headCar;
	delete tailCar;
	delete bodyCar;

	return 0;
}
#endif 