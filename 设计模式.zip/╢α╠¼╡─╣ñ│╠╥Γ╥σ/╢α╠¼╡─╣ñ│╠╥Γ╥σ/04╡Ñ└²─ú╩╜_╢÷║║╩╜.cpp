
#if 0
#include <iostream>
using namespace std;
//�����ò��ö��󶼴��ڣ��е��˷���Դ
class SingleIton
{
public:
	static SingleIton* getInstrance()
	{		
		return m_pThis;
	}
	static void freeInstrance()
	{
		if (m_pThis != nullptr)
		{
			delete m_pThis;
			m_pThis = nullptr;
		}
	}
private:
	static SingleIton* m_pThis;
	SingleIton()
	{
		cout << "singleItom constructor  work" << endl;
	}
};
SingleIton* SingleIton::m_pThis = new SingleIton;

int main04()
{
	SingleIton* p1 = SingleIton::getInstrance();
	SingleIton* p2 = SingleIton::getInstrance();

	if (p1 == p2)
	{
		cout << " == " << endl;
	}
	else
	{
		cout << " != " << endl;
	}
	SingleIton::freeInstrance();

	getchar();
	return 0;
}
#endif
