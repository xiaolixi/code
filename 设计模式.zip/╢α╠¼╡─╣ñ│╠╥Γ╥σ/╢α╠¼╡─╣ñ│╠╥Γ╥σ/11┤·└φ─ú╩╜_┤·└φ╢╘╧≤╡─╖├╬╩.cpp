#if 0

#include <iostream>

using namespace std;

class Subject
{
public:
	virtual void sailbook() = 0;
};

class RealSubjectBook : public Subject
{
public:
	virtual void sailbook()
	{
		cout << "sell book" << endl;
	}
};

class Proxy : public Subject
{
public:
	Proxy()
	{
		m_deal = new RealSubjectBook;
	}
	~Proxy()
	{
		delete m_deal;
	}
	void sailbook()
	{
		dazhe();
		m_deal->sailbook();
	}
	void dazhe()
	{
		cout << "˫ʮһ" << endl;
	}
private:
	Subject* m_deal;
};

int main11()
{
	Proxy* pP = new Proxy;
	pP->sailbook();
	delete pP;
	return 0;
}




class Player
{
public:
	virtual void playGame() = 0;
};

class LiXiaoyao :public Player
{
public:
	void playGame()
	{
		cout << " �Һ�˧" << endl;
	}
};

class GameProxy :public Player
{
public:
	GameProxy()
	{
		m_player = new LiXiaoyao;
	}
	~GameProxy()
	{
		delete m_player;
	}
	void playGame()
	{
		cout << " ���Ǵ�������ң��ֵ�" << endl;
		m_player->playGame();
	}
private:
	Player* m_player;
};

#endif