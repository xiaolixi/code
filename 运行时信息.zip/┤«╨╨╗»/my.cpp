#include <iostream>

int main(){

	char c[20];
	std::cout << sizeof(c) << " " << (int)c << " " << int(c + 1) << "\n";
}