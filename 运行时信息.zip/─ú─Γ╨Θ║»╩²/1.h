
#include <iostream>
using namespace std;

#define myvirtual 
typedef 
class Shape{
public:
	myvirtual void getcolor(){
		cout << "Shape getcolor() " << endl;
	}
	myvirtual int getarea(){
		cout << "Shape getarea() " << endl;
		return 0;
	}
};
class Rectangle :public Shape{
public:
	Rectangle(int w, int l) :width(w), length(l){}
	myvirtual void getcolor(){
		cout << "Rectangle getcolor() " << endl;
	}
	myvirtual int getarea(){
		cout << "Rectangle getarea()" << endl;
		return width * length;
	}
	myvirtual int getwidth(){
		cout << "Rectangle getwidth()" << endl;
		return width;
	}
private:
	int width;
	int length;
};
class Square :public Rectangle{
public:
	Square(int w, int l) :Rectangle(w, l){}
	myvirtual void getcolor(){
		cout << "Square getcolor() " << endl;
	}
	myvirtual int getarea(){
		cout << "Square getarea()" << endl;
	}
};

