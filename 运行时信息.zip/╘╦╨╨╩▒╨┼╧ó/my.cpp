#include "my.h"
#include <iostream>
#include <iomanip>
using namespace std;

IMPLEMENT_DYNAMIC(CMyWinApp, CWinApp)
CMyWinApp theApp;

BOOL CMyWinApp::InitInstance()
{
	m_pMainWnd = new CMyFrameWnd;
	return TRUE;
}

CMyFrameWnd::CMyFrameWnd()
{
	Create();
}

void PrintAllClasses()
{
	CRuntimeClass* pClass = NULL;
	
	cout << "_______________________________________CRuntimeClass's infromation__________________________________________\n\n";
	cout << setw(10) << "m_lpszClassName\t\tm_nObjectSize\tm_wSchema\tm_pfnCreateObject\tm_pBaseClass\tm_pNextClass\n";
	
	// just walk through the simple list of registered classes
	for (pClass = CRuntimeClass::pFirstClass; pClass != NULL;
		pClass = pClass->m_pNextClass)
	{
		cout << setw(15) << pClass->m_lpszClassName << "\t";
		cout << setw(15) << pClass->m_nObjectSize << "\t";
		cout << setw(15) << pClass->m_wSchema << "\t";
		cout << setw(20) << pClass->m_pfnCreateObject << "\t";
		cout << setw(20) << pClass->m_pBaseClass << "\t";
		cout << setw(10) << pClass->m_pNextClass << "\t";
		cout << setw(10) << " address " << pClass << "\n";
	}
	cout << "����ͷָ��Ϊ " << CRuntimeClass::pFirstClass << endl;
}
//------------------------------------------------------------------
// main
//------------------------------------------------------------------
void main()
{
	CWinApp* pApp = AfxGetApp();

	pApp->InitApplication();
	pApp->InitInstance();
	pApp->Run();

	PrintAllClasses();


	cout << "______________RTTI______________" << "\n";
	cout << pApp->IsKindOf(RUNTIME_CLASS(CMyWinApp)) << endl;
	cout << pApp->IsKindOf(RUNTIME_CLASS(CWinApp)) << endl;
	cout << pApp->IsKindOf(RUNTIME_CLASS(CWinThread)) << endl;
	cout << pApp->IsKindOf(RUNTIME_CLASS(CCmdTarget)) << endl;
	cout << pApp->IsKindOf(RUNTIME_CLASS(CObject)) << endl;
	cout << pApp->IsKindOf(RUNTIME_CLASS(CWnd)) << endl;
}
//------------------------------------------------------------------

